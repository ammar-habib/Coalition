<?php
/**
 * CT Custom Theme Customizer
 *
 * @package CT_Custom
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function ct_custom_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'blogname', array(
			'selector'        => '.site-title a',
			'render_callback' => 'ct_custom_customize_partial_blogname',
		) );
		$wp_customize->selective_refresh->add_partial( 'blogdescription', array(
			'selector'        => '.site-description',
			'render_callback' => 'ct_custom_customize_partial_blogdescription',
		) );

//        $wp_customize->add_section( 'address_section', array(
//            'title' => __( 'Address'),
//            'description' => __( 'Enter Your Address' ),
//        ));
//        $wp_customize->add_setting( 'address_section_area', array(
//            'default' => __( '535 La Plata Street 4200 Argentina')
//        ));
//        $wp_customize->add_control( 'address_section_area', array(
//            'label' => __( 'Address'),
//            'section' => __( 'address_section' ),
//            'type' => 'textarea',
//            'priorty' => 1,
//
//        ));
//        $wp_customize->add_setting( 'phone_number', array(
//            'default' => __('385.154.11.28.38')
//        ));
//        $wp_customize->add_control( 'phone_number', array(
//            'label' => __( 'Phone'),
//            'section' => __( 'address_section' ),
//            'type' => 'input',
//            'priorty' => 2,
//        ));
//        $wp_customize->add_setting( 'fax_number', array(
//            'default' => __('385.154.11.28.38')
//        ));
//        $wp_customize->add_control( 'fax_number', array(
//            'label' => __( 'Fax'),
//            'section' => __( 'address_section' ),
//            'type' => 'input',
//            'priorty' => 3,
//        ));


        //Address
        $wp_customize->add_section( 'address', array(
            'title' => __( 'Address'),
            'description' => __( 'Enter Your Address Details' ),
        ));
        $address_details = [
            'Name' => 'name',
            'Address' => 'address',
            'Phone' => 'phone',
            'Fax' => 'fax',
        ];
        foreach ($address_details as $address_label => $address_name){
            $setting_id = sprintf('address_%s', $address_name);
            $wp_customize->add_setting($setting_id, array(
                'default' => __(''),
//                'sanitize_callback' => 'absint',
            ));

            $fieldType  = 'input';
            if($address_name == 'address'){
                $fieldType  = 'textarea';
            }
            $wp_customize->add_control(
                new WP_Customize_Control(
                    $wp_customize,
                    $setting_id,
                    array(
                        'label' => __($address_label),
                        'section' => __( 'address' ),
                        'settings' => $setting_id,
                        'type' => $fieldType,
                    )
                )
            );
        }

        //social links
        $wp_customize->add_section( 'social_links', array(
            'title' => __( 'Social Links'),
            'description' => __( 'Social links details' ),
        ));
        $social_links = [
          'Facebook' => 'facebook',
          'Twitter' => 'twitter',
          'Linkedin' => 'linkedin',
          'Pinterest' => 'pinterest',
        ];
        foreach ($social_links as $social_label => $social_name){
             $setting_id = sprintf('social_%s', $social_name);
            $wp_customize->add_setting($setting_id, array(
                'default' => __(''),
//                'sanitize_callback' => 'absint',
            ));

            $wp_customize->add_control(
                new WP_Customize_Control(
                    $wp_customize,
                    $setting_id,
                    array(
                        'label' => __($social_label),
                        'section' => __( 'social_links' ),
                        'settings' => $setting_id,
                        'type' => 'input',
                    )
                )
            );
        }

	}
}
add_action( 'customize_register', 'ct_custom_customize_register' );

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function ct_custom_customize_partial_blogname() {
	bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function ct_custom_customize_partial_blogdescription() {
	bloginfo( 'description' );
}



/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function ct_custom_customize_preview_js() {
	wp_enqueue_script( 'ct-custom-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'ct_custom_customize_preview_js' );
