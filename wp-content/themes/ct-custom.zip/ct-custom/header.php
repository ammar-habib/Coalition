<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package CT_Custom
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div class="wrapper">
    <header id="masthead" class="header">
        <div class="header__top">
            <div class="container">
                <div class="row align-items-center justify-content-between">
                    <div class="col py-2">
                        <ul class="list-inline mb-0 ">
                            <li class="list-inline-item">
                                <span class="header__top__text">Call us now!</span>
                            </li>
                            <li class="list-inline-item">
                                <?php
                                $setting_id = sprintf('address_%s', 'phone');
                                $phone = get_theme_mod($setting_id);
                                echo "<a class='header__top__link' href='tel:$phone'>$phone</a>";
                                ?>
                            </li>
                        </ul>
                    </div>
                    <div class="col py-2 text-end">
                        <ul class="list-inline mb-0 me-3">
                            <li class="list-inline-item">
                                <a class="header__top__link" href="#">Login</a>
                            </li>
                            <li class="list-inline-item">
                                <a class="header__top__link" href="#">Signup</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
                    <?php
                    $custom_logo_id = get_theme_mod('custom_logo');
                    $logo = wp_get_attachment_image_src($custom_logo_id, 'full');
                    $srcset = wp_get_attachment_image_srcset($custom_logo_id, 'full');
                    $sizes = wp_get_attachment_image_sizes($custom_logo_id, 'full');
                    $alt = get_post_meta($custom_logo_id, '_wp_attachment_image_alt', true);
                    if (has_custom_logo()) {
                        echo '<img width="173" height="38"  src="' . esc_url($logo[0]) . '" srcset="' . esc_attr($srcset) . '"  sizes="' . esc_attr($sizes) . '" alt="' . get_bloginfo('name') . '">';
                    }
                    ?>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
                    <?php
                    wp_nav_menu(array(
                        'theme_location' => 'menu-1',
                        'menu_id' => 'primary-menu',
                        'menu_class' => 'navbar-nav d-flex align-items-center ms-auto',
                        'container_class' => 'collapse navbar-collapse',
                        'container_id' => 'navbarTogglerDemo01',
                        'container' => 'ul',
                    ));
                    ?>
                </div>
            </div>
        </nav>
    </header>

    <main id="content" class="page-content">
