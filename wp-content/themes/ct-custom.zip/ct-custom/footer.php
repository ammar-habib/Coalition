<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package CT_Custom
 */

?>
	</main><!-- #content -->
</div><!-- #page -->

<?php wp_footer(); ?>
<script>
    $("ul.sub-menu").parent().addClass("dropdown");
    $("ul.sub-menu").addClass("dropdown-menu");
    $("ul#primary-menu li.dropdown a").addClass("dropdown-toggle");
    $("ul.sub-menu li a").removeClass("dropdown-toggle");
    $('.navbar .dropdown-toggle').append('');
    $('a.dropdown-toggle').attr('data-bs-toggle', 'dropdown');
</script>
</body>
</html>
