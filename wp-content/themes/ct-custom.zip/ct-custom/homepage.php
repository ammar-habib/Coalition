<?php
/**
 * Template Name: Home page
 * The template for displaying for Home page
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package CT_Custom
 */

get_header();
?>

    <div class="container">
        <?php while (have_posts()) : the_post(); ?>
            <?php the_content('Read More'); ?>
        <?php endwhile; ?>
    </div>
<?php
get_footer();
